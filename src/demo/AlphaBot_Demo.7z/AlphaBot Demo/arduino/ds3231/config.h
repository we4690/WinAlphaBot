#ifndef __config_h_
#define __config_h_

// comment this out if you need unixtime support
// this will add about 324bytes to your firmware
//#define CONFIG_UNIXTIME

#endif
